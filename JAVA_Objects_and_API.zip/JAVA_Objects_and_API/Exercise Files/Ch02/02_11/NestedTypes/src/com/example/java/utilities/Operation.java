package com.example.java.utilities;

public enum Operation {
    ADD, SUBTRACT;
}
