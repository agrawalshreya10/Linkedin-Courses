package com.example.java.model;

public class Shirt extends ClothingItem {
    public Shirt(String size, double price) {
        super("Shirt", size, price);
    }
}
