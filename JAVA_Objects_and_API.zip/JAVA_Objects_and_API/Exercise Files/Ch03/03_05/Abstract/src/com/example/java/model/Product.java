package com.example.java.model;

public interface Product {

    String getType();
    String getSize();
    double getPrice();

}
